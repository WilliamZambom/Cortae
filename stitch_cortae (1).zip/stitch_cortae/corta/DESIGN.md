---
version: alpha
name: CortaÊ
description: Design system da plataforma de agendamento online para barbearias CortaÊ
  — área do cliente (mobile-first) e painel da barbearia (desktop).
colors:
  primary: '#1C1F24'
  secondary: '#5F6670'
  accent: '#A85A2A'
  accent-strong: '#8E4A21'
  accent-soft: '#F4E6DC'
  on-accent: '#FFFFFF'
  neutral: '#FAF7F2'
  surface: '#FFFFFF'
  border: '#E7E1D8'
  sidebar: '#1C1F24'
  on-sidebar: '#F5F1EA'
  success: '#15803D'
  success-soft: '#DCFCE7'
  warning: '#B45309'
  warning-soft: '#FEF3C7'
  error: '#B91C1C'
  error-soft: '#FEE2E2'
  info: '#1D4ED8'
  info-soft: '#DBEAFE'
  noshow: '#6B21A8'
  noshow-soft: '#F3E8FF'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f0ede9'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#45474b'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#76777b'
  outline-variant: '#c6c6cb'
  surface-tint: '#5c5e64'
  on-primary: '#ffffff'
  primary-container: '#1c1f24'
  on-primary-container: '#84868d'
  inverse-primary: '#c4c6cd'
  on-secondary: '#ffffff'
  secondary-container: '#dce3ef'
  on-secondary-container: '#5e656f'
  tertiary: '#100300'
  on-tertiary: '#ffffff'
  tertiary-container: '#381400'
  on-tertiary-container: '#c5713f'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e2e9'
  primary-fixed-dim: '#c4c6cd'
  on-primary-fixed: '#191c21'
  on-primary-fixed-variant: '#44474c'
  secondary-fixed: '#dce3ef'
  secondary-fixed-dim: '#c0c7d2'
  on-secondary-fixed: '#151c24'
  on-secondary-fixed-variant: '#404751'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68e'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763304'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
typography:
  display:
    fontFamily: Manrope
    fontSize: 2rem
    fontWeight: 700
    lineHeight: 1.2
    letterSpacing: -0.02em
  h1:
    fontFamily: Manrope
    fontSize: 1.5rem
    fontWeight: 700
    lineHeight: 1.25
  h2:
    fontFamily: Manrope
    fontSize: 1.25rem
    fontWeight: 600
    lineHeight: 1.3
  h3:
    fontFamily: Manrope
    fontSize: 1.0625rem
    fontWeight: 600
    lineHeight: 1.4
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: 400
    lineHeight: 1.5
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: 400
    lineHeight: 1.45
  label-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: 600
    lineHeight: 1.2
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: 0.02em
  numeric:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: 600
    lineHeight: 1.2
    fontFeature: tnum
  headline-lg:
    fontFamily: Manrope
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 1.875rem
  headline-md:
    fontFamily: Manrope
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.625rem
  headline-sm:
    fontFamily: Manrope
    fontSize: 1.0625rem
    fontWeight: '600'
    lineHeight: 1.5rem
rounded:
  sm: 6px
  md: 10px
  lg: 16px
  sheet: 20px
  full: 999px
  DEFAULT: 0.5rem
  xl: 1.5rem
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
components:
  button-primary:
    backgroundColor: '{colors.accent}'
    textColor: '{colors.on-accent}'
    typography: '{typography.label-md}'
    rounded: '{rounded.md}'
    height: 48px
    padding: 0 20px
  button-primary-hover:
    backgroundColor: '{colors.accent-strong}'
  button-secondary:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.primary}'
    typography: '{typography.label-md}'
    rounded: '{rounded.md}'
    height: 48px
    padding: 0 20px
  button-destructive:
    backgroundColor: '{colors.error}'
    textColor: '{colors.on-accent}'
    typography: '{typography.label-md}'
    rounded: '{rounded.md}'
    height: 48px
    padding: 0 20px
  input:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.primary}'
    typography: '{typography.body-md}'
    rounded: '{rounded.md}'
    height: 48px
    padding: 0 14px
  card:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.primary}'
    rounded: '{rounded.lg}'
    padding: 16px
  chip-horario:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.primary}'
    typography: '{typography.numeric}'
    rounded: '{rounded.full}'
    height: 44px
    padding: 0 16px
  chip-horario-selected:
    backgroundColor: '{colors.accent}'
    textColor: '{colors.on-accent}'
  option-selected:
    backgroundColor: '{colors.accent-soft}'
    textColor: '{colors.accent-strong}'
  badge-pendente:
    backgroundColor: '{colors.warning-soft}'
    textColor: '{colors.warning}'
    typography: '{typography.label-sm}'
    rounded: '{rounded.full}'
    padding: 2px 10px
  badge-confirmado:
    backgroundColor: '{colors.info-soft}'
    textColor: '{colors.info}'
    typography: '{typography.label-sm}'
    rounded: '{rounded.full}'
    padding: 2px 10px
  badge-concluido:
    backgroundColor: '{colors.success-soft}'
    textColor: '{colors.success}'
    typography: '{typography.label-sm}'
    rounded: '{rounded.full}'
    padding: 2px 10px
  badge-cancelado:
    backgroundColor: '{colors.error-soft}'
    textColor: '{colors.error}'
    typography: '{typography.label-sm}'
    rounded: '{rounded.full}'
    padding: 2px 10px
  badge-nao-compareceu:
    backgroundColor: '{colors.noshow-soft}'
    textColor: '{colors.noshow}'
    typography: '{typography.label-sm}'
    rounded: '{rounded.full}'
    padding: 2px 10px
  bottom-nav:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.secondary}'
    height: 64px
  sidebar:
    backgroundColor: '{colors.sidebar}'
    textColor: '{colors.on-sidebar}'
    width: 248px
---

